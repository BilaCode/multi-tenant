<?php
use Illuminate\Support\Facades\Route;
use YourNamespace\FacebookPixelInserter\Http\Controllers\FacebookPixelInserterController;

Route::get('insert-facebook-pixel', [FacebookPixelInserterController::class, 'insertPixel']);
