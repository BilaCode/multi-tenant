<?php
return [
    'default_pixel_code' => '<!-- Your pixel code here -->',
    'facebook_pixel_id' => env('FACEBOOK_PIXEL_ID', 'your-default-pixel-id'),
];
