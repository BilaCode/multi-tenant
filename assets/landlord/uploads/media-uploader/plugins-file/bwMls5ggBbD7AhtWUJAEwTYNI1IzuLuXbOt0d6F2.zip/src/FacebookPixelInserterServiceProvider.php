<?php
namespace YourNamespace\FacebookPixelInserter;

use Illuminate\Support\ServiceProvider;

class FacebookPixelInserterServiceProvider extends ServiceProvider
{
    public function boot()
    {
        $this->publishes([
            __DIR__.'/config/facebookpixelinserter.php' => config_path('facebookpixelinserter.php'),
        ]);

        $this->loadViewsFrom(__DIR__.'/resources/views', 'facebookpixelinserter');

        $this->loadRoutesFrom(__DIR__.'/routes/web.php');

        \Illuminate\Support\Facades\Blade::directive('insertFacebookPixel', function ($expression) {
            $pixelID = config('facebookpixelinserter.facebook_pixel_id');
            return "<?php echo \"<script>
                !function(f,b,e,v,n,t,s)
                {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
                n.callMethod.apply(n,arguments):n.queue.push(arguments)};
                if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
                n.queue=[];t=b.createElement(e);t.async=!0;
                t.src=v;s=b.getElementsByTagName(e)[0];
                s.parentNode.insertBefore(t,s)}(window, document,'script',
                'https://connect.facebook.net/en_US/fbevents.js');
                fbq('init', '$pixelID');
                fbq('track', 'PageView');
            </script>\"; ?>";
        });
    }

    public function register()
    {
        $this->mergeConfigFrom(
            __DIR__.'/config/facebookpixelinserter.php', 'facebookpixelinserter'
        );
    }
}
